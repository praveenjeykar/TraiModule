package com.cg;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Author {
	@Id
	private String firstName;
	 private String MiddleName;
	 private String Lastname;
	 private int phoneNo;
	
	private int Id;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return MiddleName;
	}
	public void setMiddleName(String middleName) {
		MiddleName = middleName;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public int getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}
	@Override
	public String toString() {
		return "Author [firstName=" + firstName + ", MiddleName=" + MiddleName + ", Lastname=" + Lastname + ", phoneNo="
				+ phoneNo + ", Id=" + Id + "]";
	}
	
}	
	
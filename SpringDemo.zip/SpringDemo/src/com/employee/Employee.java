package com.employee;

public class Employee {
 private int EmployeeId;
 private String EmployeeName;
 private int Salary;
 private String BusinessUnit;
 private int age;
 
 
 public int getSalary() {
	return Salary;
}
public void setSalary(int salary) {
	Salary = salary;
}

 public int getEmployeeId() {
	return EmployeeId;
}
public void setEmployeeId(int employeeId) {
	EmployeeId = employeeId;
}
public String getEmployeeName() {
	return EmployeeName;
}
public void setEmployeeName(String employeeName) {
	EmployeeName = employeeName;
}


public String getBusinessUnit() {
	return BusinessUnit;
}
public void setBusinessUnit(String businessUnit) {
	BusinessUnit = businessUnit;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}

@Override
public String toString() {
	return " EmployeeId=" + EmployeeId + "\n"
			+ " EmployeeName=" + EmployeeName + "\n"
			+ " Salary=" + Salary+ "\n"
					+ " BusinessUnit=" + BusinessUnit + "\n"
							+ " age=" + age;
}

public void draw() {
	System.out.print("Employee Details\n");
	System.out.print("----------------------\n");
}
}

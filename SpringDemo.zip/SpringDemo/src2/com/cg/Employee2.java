package com.cg;

public class Employee2 {
	private int EmployeeAge;
	private int EmployeeId;
	private String EmployeeName;
	private double salary;
	
	public int getEmployeeAge() {
		return EmployeeAge;
	}
	public void setEmployeeAge(int employeeAge) {
		EmployeeAge = employeeAge;
	}
	
	
	public int getEmployeeId() {
		return EmployeeId;
	}
	public void setEmployeeId(int employeeId) {
		EmployeeId = employeeId;
	}
	public String getEmployeeName() {
		return EmployeeName;
	}
	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
	
	@Override
	public String toString() {
		return "Employee2 [EmployeeAge=" + EmployeeAge + ", EmployeeId=" + EmployeeId + ", EmployeeName=" + EmployeeName
				+ ", salary=" + salary + "]";
	}
	public void show() {
	System.out.println("Employee Details:-------------");	
		
	}
	

}

package Login;


import static org.junit.Assert.assertEquals;

import org.cg.bdd.bean.User;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {

User user1=new User();

@Given("^User is on Home page$")
public void user_is_on_Home_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Given("^Login  link is available$")
public void login_link_is_available() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^user enters username and password$")
public void user_enters_username_and_password() throws Throwable {
	user1.setUsername("Moni");
	   user1.setPassword("Lalitha@123");
}

@When("^credentials are correct$")
public void credentials_are_correct() throws Throwable {
	assertEquals("Moni",user1.getUsername());
	assertEquals("Lalitha@1223",user1.getPassword());
	
}

@Then("^display message 'success'$")
public void display_message_success() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}


@When("^user doestn't enter anything$")
public void user_doestn_t_enter_anything() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@When("^if entered credentials are incorrect$")
public void if_entered_credentials_are_incorrect() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}

@Then("^Display message as 'Please enter valid inputs'$")
public void display_message_as_Please_enter_valid_inputs() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
}
}
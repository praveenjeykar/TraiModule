package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
public class FindAuthor {
	public static void main(String args[]) {
		System.out.println("Welcome");
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		 EntityManager em= factory.createEntityManager();
		 Author aut= new Author();
		 em.getTransaction().begin();
		 
		 aut.setId(411);
		 aut.setFirstName("monica");
		 aut.setMiddleName("moni");
		 aut.setLastname("beera");
		 aut.setPhoneNo(89192);
		
		 em.persist(aut);
		 em.getTransaction().commit();
		
	}

}

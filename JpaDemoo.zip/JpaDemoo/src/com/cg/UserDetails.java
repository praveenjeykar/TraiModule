package com.cg;

public class UserDetails {

	public void setID(int i) {
		// TODO Auto-generated method stub
		
	}

	public void setName(String string) {
		// TODO Auto-generated method stub
		
	}

}

package com.cg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SubEmp2 {
	public static void main(String args[]) {
		   ApplicationContext context = new ClassPathXmlApplicationContext("spring2.xml");
//		   Employee2 emp = (Employee2) context.getBean("employee2");
		   SBU2 sbu =context.getBean("Sbu2",SBU2.class);
		   System.out.println(sbu);
		   
//		   System.out.println(emp);
//		   emp.show();
}
}

package com.su;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.employee.Employee;

public class EmpSbuMain {
	public static void main(String args[]) {
		   ApplicationContext context = new ClassPathXmlApplicationContext("spring1.xml");
		   Employee1 emp = context.getBean("employee",Employee1.class);
		   SBU sbu =context.getBean("Sbu",SBU.class);
		   emp.show();
		   System.out.println(emp);
		   
}
}

package com.au;
import java.awt.print.Book;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.cg.Author;
 

public class main2 {
	
	
	    public static void main(String[] args) {
	    EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
	    EntityManager entityManager=factory.createEntityManager();
	    Author2 author2=new Author2();
	    author2.setName("ChetanBhagat");
	    
	    Book2 b1=new Book2();
	    b1.setTitle("alice in the wonderland");
	    b1.setPrice(129);
	  
	    
	    Book2 b2=new Book2();
	    b2.setTitle("Two States");
	    b2.setPrice(300);
	     author2.getBook2().add(b1);
	     author2.getBook().add(b2);
	    
	    
	    
	    entityManager.getTransaction().begin();
	    
	    entityManager.persist(author2);
	    TypedQuery<Book> query1=entityManager.createQuery("select book from author2 a join a.book b where a.name=:aname",Book.class);
	    List<Book> book=query1.getResultList();
	    query1.setParameter("aname","Robinsharma");
	    for(Book b11:book) {
	        System.out.println(book);
	   
	    System.out.println();
	    TypedQuery<Author> query2=entityManager.createQuery("from Author where name='Chetan Bhagat'", Author.class);
	    Author authorId=query2.getSingleResult();
	    int getId=authorId.getId();
	    TypedQuery<Book> query3=entityManager.createQuery("from Book where ID=:id", Book.class);
	    query3.setParameter("id", getId);
	    List<Book> books2=query3.getResultList();
	    for(Book bo
	    		ok:books2) {
	    System.out.println(book);
	 }
	    System.out.println();
	    TypedQuery<Book> query4=entityManager.createQuery("from Book where price between 100 and 150", Book.class);
	    List<Book> books3=query4.getResultList();
	    for(Book book:books3) {
	    System.out.println(book);
	 }
	    System.out.println();
	    
	    TypedQuery<Book> query5=entityManager.createQuery("from Book where ISBN=:gisbn", Book.class);
	    query5.setParameter("gisbn", book1.getISBN());
	    Book bookIsbn=query5.getSingleResult();
	    int bookId=bookIsbn.getAuthor().getID();
	    System.out.println(bookId);
	    TypedQuery<Author> query6=entityManager.createQuery("from Author where ID=:id", Author.class);
	    query6.setParameter("id", bookId);
	    Author authors=query6.getSingleResult();
	    System.out.println(authors.getFirstName());
	    System.out.println();
	    
	    entityManager.getTransaction().commit();
	 
	}
	}
	
	


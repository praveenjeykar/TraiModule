package com.su;

public class Employee1 {
	 private int EmployeeId;
	 private String EmployeeName;
	 private double Salary;
	 private SBU BusinessUnit;
	 
	 @Override
	public String toString() {
		return "Employee1 [EmployeeId=" + EmployeeId + ", EmployeeName=" + EmployeeName + ", Salary=" + Salary
				+ "\n"+"BusinessUnit=" + BusinessUnit + "]";
	}
	public int getEmployeeId() {
		return EmployeeId;
	}
	public void setEmployeeId(int employeeId) {
		EmployeeId = employeeId;
	}
	public String getEmployeeName() {
		return EmployeeName;
	}
	public void setEmployeeName(String employeeName) {
		EmployeeName = employeeName;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		Salary = salary;
	}
	public SBU getBusinessUnit() {
		return BusinessUnit;
	}
	public void setBusinessUnit(SBU businessUnit) {
		BusinessUnit = businessUnit;
	}
	public void show() {
		System.out.println("Employee Details\n");
		System.out.println("--------------------\n");
		
	}
	
}

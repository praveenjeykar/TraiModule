package com.pg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainBookAuthor {
   public static void main(String args[]) {
	   System.out.println("Hi Monica");
	   EntityManagerFactory factory= Persistence.createEntityManagerFactory("JPA-PU");
	   EntityManager entitymanager=factory.createEntityManager();
	   
	   entitymanager.getTransaction().begin();
	   
	   Author author= new Author();
	   Books book=new Books();
	   author.setCost(12);
	   author.setAuthorName("sarvat");
	   
	   book.setId(1);
	   book.setName("Angle");
	   book.setAutName("Monica");
	   book.setPageNo(765);
	   
	   entitymanager.persist(author);
	   entitymanager.persist(book);
		 
	   entitymanager.getTransaction().commit();
		 System.out.println("completed");
		 entitymanager.close();
		 factory.close();
		 
   }
}

package com.cg;

import java.util.List;
import java.util.ArrayList;

public class SBU2 {
private String subCode;
private String subName;
private String subHead;
List<Employee2> Emplist =new ArrayList<>();

  public List<Employee2> getEmplist() {
	return Emplist;
}


public void setEmplist(List<Employee2> emplist) {
	Emplist = emplist;
}



public String getSubCode() {
	return subCode;
}


public void setSubCode(String subCode) {
	this.subCode = subCode;
}


public String getSubName() {
	return subName;
}


public void setSubName(String subName) {
	this.subName = subName;
}


public String getSubHead() {
	return subHead;
}


public void setSubHead(String subHead) {
	this.subHead = subHead;
}







@Override
public String toString() {
	return "SBU2 [subCode=" + subCode + ", subName=" + subName + ", subHead=" + subHead + ", Emplist=" + Emplist + "]";
}


public void show1() {
	System.out.println("SBU Details\n");
	System.out.println("-----------------");
}

}

package com.cg;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Vechile {
	@Id
    private int vechileId;
    private String vechileName;
    private UserDetails user;
    
    
    public UserDetails getUser() {
		return user;
	}
	public void setUser(UserDetails user) {
		this.user = user;
	}
	public int getVechileId() {
		return vechileId;
	}
	public void setVechileId(int vechileId) {
		this.vechileId = vechileId;
	}
	public String getVechileName() {
		return vechileName;
	}
	public void setVechileName(String vechileName) {
		this.vechileName = vechileName;
	}
	
	@Override
	public String toString() {
		return "Vechile [vechileId=" + vechileId + ", vechileName=" + vechileName + "]";
	}
    
}

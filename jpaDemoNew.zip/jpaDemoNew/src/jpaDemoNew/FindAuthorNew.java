package jpaDemoNew;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class FindAuthorNew {
   public static void main(String args[]) {
	   System.out.println("welcome");
	   EntityManagerFactory factory= Persistence.createEntityManagerFactory("JPA-PU");
	   EntityManager entitymanager=factory.createEntityManager();
	   Author1 aut= new Author1();
	   entitymanager.getTransaction().begin();
		 
		
//		
//		 aut.setId(414);
//		 aut.setFirstName("anitha");
//		 aut.setLastName("jgfh");
//		 aut.setPhoneNo(90890891);
//		 
//		
//		 aut.setId(454);
//		 aut.setFirstName("monica");
//		 aut.setLastName("moni");
//		 aut.setPhoneNo(8917654);
//		 
//		 entitymanager.persist(aut);
		 
		 Author1 a=entitymanager.find(Author1.class,414);
		 entitymanager.remove(a);
		 
		 Author1 b=entitymanager.find(Author1.class,454);
		 b.setFirstName("loiiiuytrew");
	
		 
		 entitymanager.getTransaction().commit();
		 System.out.println("completed");
		 entitymanager.close();
		 factory.close();
   }
}
